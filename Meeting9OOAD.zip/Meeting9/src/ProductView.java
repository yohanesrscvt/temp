import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

public class ProductView extends JFrame {

	private static final long serialVersionUID = 1L;
	
	JPanel topPanel, midPanel, bottomPanel;
	JTable productTable;
	JScrollPane scrollPane;
	JLabel titleLbl, authorLbl, priceLbl;
	JTextField titleTf, authorTf;
	JSpinner priceSpinner;
	JButton insertBtn, updateBtn, deleteBtn;
	
	Vector<Product> productVector;

	public ProductView() {
		this.setSize(new Dimension(600, 350));
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setLayout(new BorderLayout());
		
		addDummyProduct();
		initiateTable();

		configureMidPanel();
		configureBottomPanel();
		addPanels();
		
		this.setVisible(true);
	}
	
	public void addDummyProduct() {
		productVector = new Vector<>();
		productVector.add(new Product(Long.valueOf(1), "The Secret", "Rhonda Byrne", 320000));
		productVector.add(new Product(Long.valueOf(2), "Atomic Habits", "James Clears", 280000));
		productVector.add(new Product(Long.valueOf(3), "Thinking, Fast and Slow", "Daniel Kahneman", 260000));
	}
	
	public void updateTable() {
		Vector<String> headers = new Vector<>();
		headers.add("ID");
		headers.add("Book Title");
		headers.add("Book Author");
		headers.add("Book Price");
		
		DefaultTableModel dtm = new DefaultTableModel(headers, 0);

		for (Product product : productVector) {
			Vector<Object> row = new Vector<>();
			row.add(product.getId());
			row.add(product.getTitle());
			row.add(product.getAuthor());
			row.add(product.getPrice());
			row.add(product.getPrice());
			dtm.addRow(row);
		}
		productTable.setModel(dtm);
	}
	
	public void initiateTable() {
		topPanel = new JPanel(new FlowLayout());
		productTable = new JTable() {
			private static final long serialVersionUID = 1L;
			@Override
			public boolean isCellEditable(int row, int column) {
				// TODO Auto-generated method stub
				return false;
			}
		};
		
		updateTable();
		
		scrollPane = new JScrollPane(productTable);
		scrollPane.setPreferredSize(new Dimension(350, 200));
		
		topPanel.add(scrollPane);
	}
	
	public void configureMidPanel() {
		midPanel = new JPanel(new GridBagLayout());

		titleLbl = new JLabel("Title: ");
		authorLbl = new JLabel("Author: ");
		priceLbl = new JLabel("Price: ");

		titleTf = new JTextField();
		authorTf = new JTextField();
		SpinnerModel sm = new SpinnerNumberModel(0, 0, 1000000, 10000);
		priceSpinner = new JSpinner(sm);

		GridBagConstraints c = new GridBagConstraints();
		c.weightx = 1;
	    c.fill=GridBagConstraints.HORIZONTAL;
	    
		c.gridx = 0;
		c.gridy = 0;
		midPanel.add(titleLbl, c);
		c.gridx = 1;
		midPanel.add(titleTf, c);

		c.gridx = 0;
		c.gridy = 1;
		midPanel.add(authorLbl, c);
		c.gridx = 1;
		midPanel.add(authorTf, c);

		c.gridx = 0;
		c.gridy = 2;
		midPanel.add(priceLbl, c);
		c.gridx = 1;
		midPanel.add(priceSpinner, c);
	}
	
	public void configureBottomPanel() {
		bottomPanel = new JPanel(new FlowLayout());

		insertBtn = new JButton("Insert");
		updateBtn = new JButton("Update");
		deleteBtn = new JButton("Delete");
		
		bottomPanel.add(insertBtn);
		bottomPanel.add(updateBtn);
		bottomPanel.add(deleteBtn);
	}
	
	public void addPanels() {
		this.add(topPanel, BorderLayout.NORTH);
		this.add(midPanel, BorderLayout.CENTER);
		this.add(bottomPanel, BorderLayout.SOUTH);
	}

}
