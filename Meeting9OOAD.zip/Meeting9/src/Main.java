import java.awt.EventQueue;

public class Main {

	public Main() {
		new ProductView();
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				new Main();
			}
		});
	}

}
